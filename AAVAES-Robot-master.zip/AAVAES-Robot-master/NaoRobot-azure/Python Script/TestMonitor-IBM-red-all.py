import requests
import speech_recognition as sr
import socket
import requests
import json

import threading

import random
import base64



def printit():
  threading.Timer(5.0, printit).start()
  print "Hello, event!"
  # Currently only monitor temperature
  sTemplate = "Device/SubDeviceList/%s/Temperature/Sensor/Value"
  jsonTemplate = '{"deviceId":"Pepper-Madrid-01", "deviceType":"Robot", \"battery\":%s, \"head\":%s,\"lHand\":%s,\"rHand\":%s}'


  batterySensors = sTemplate % "Battery"
  headSensors = sTemplate % "Head"
  lHandSensors = sTemplate % "LHand"
  rHandSensors = sTemplate % "RHand"

  # batteryValue = str(round(self.memory.getData(batterySensors), 2))
  # headValue = str(round(self.memory.getData(headSensors), 2))
  # lHandValue = str(round(self.memory.getData(lHandSensors), 2))
  # rHandValue = str(round(self.memory.getData(rHandSensors), 2))


  batteryValue = str(random.randint(3,5))
  headValue =  str(random.randint(0,60))
  lHandValue = str(random.randint(60,100))
  rHandValue = str(random.randint(60,100))

  jsonMessage = jsonTemplate % ( batteryValue, headValue, lHandValue, rHandValue)





  try:
      url = "https://nao-concierge.eu-gb.mybluemix.net/sendeventall"
      payload = jsonMessage
      headers = {
          'Content-Type': 'application/json',
      }
      response = requests.request("POST", url, data=payload, headers=headers)
      sendMessage = str(response)
      print("Send: " + payload)
      print("respomnse: " + sendMessage)

      jsonTemplate = '{"deviceId":"Pepper-Madrid-02", "deviceType":"Robot", \"battery\":%s, \"head\":%s,\"lHand\":%s,\"rHand\":%s}'

      batterySensors = sTemplate % "Battery"
      headSensors = sTemplate % "Head"
      lHandSensors = sTemplate % "LHand"
      rHandSensors = sTemplate % "RHand"

      batteryValue = str(random.randint(3, 5))
      headValue = str(random.randint(0, 60))
      lHandValue = str(random.randint(60, 100))
      rHandValue = str(random.randint(60, 100))

      jsonMessage = jsonTemplate % (batteryValue, headValue, lHandValue, rHandValue)

      payload = jsonMessage
      headers = {
          'Content-Type': 'application/json',

      }
      response = requests.request("POST", url, data=payload, headers=headers)
      sendMessage = str(response)
      print("Send: " + payload)
      print("respomnse: " + sendMessage)


  except requests.exceptions.RequestException as e:

      print(e)
  pass

printit()



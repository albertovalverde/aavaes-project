import requests
import speech_recognition as sr
import socket
import requests
import json

import threading

import random
import base64



def printit():
  threading.Timer(5.0, printit).start()
  print "Hello, event!"
  # Currently only monitor temperature
  sTemplate = "Device/SubDeviceList/%s/Temperature/Sensor/Value"
  jsonTemplate = '{\"battery\":%s, \"head\":%s,\"lHand\":%s,\"rHand\":%s}'

  batterySensors = sTemplate % "Battery"
  headSensors = sTemplate % "Head"
  lHandSensors = sTemplate % "LHand"
  rHandSensors = sTemplate % "RHand"

  # batteryValue = str(round(self.memory.getData(batterySensors), 2))
  # headValue = str(round(self.memory.getData(headSensors), 2))
  # lHandValue = str(round(self.memory.getData(lHandSensors), 2))
  # rHandValue = str(round(self.memory.getData(rHandSensors), 2))

  batteryValue = str(random.randint(2,3))
  headValue =  str(random.randint(28,40))
  lHandValue = str(random.randint(58,100))
  rHandValue = str(random.randint(38,60))

  jsonMessage = jsonTemplate % (batteryValue, headValue, lHandValue, rHandValue)

  print jsonMessage

  try:

      url = "https://nao-concierge.eu-gb.mybluemix.net/sendevent"


      payload = jsonMessage
      # headers = {
      #      'Content-Type':'application/json',
      #      'Authorization': 'Basic dXNlLXRva2VuLWF1dGg6bmFvcWlyb2JvdA==',
      #      'waitTimeSecs': '5',
      #  }

      headers = {
          'Content-Type': 'application/json',
          'Authorization': 'Basic ' + base64.b64encode('use-token-auth:naoqirobot'),
      }


      response = requests.request("POST", url, data=payload, headers=headers)
      sendMessage = str(response)
      print("test:" + sendMessage)
  except requests.exceptions.RequestException as e:

      print(e)
  pass

printit()



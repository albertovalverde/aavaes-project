import requests
import speech_recognition as sr
import socket
import requests
import json


response = "Conversation"

url = "http://localhost:7071/api/RecordConversation?code=KEoyCZvBXPgJzaaBpZMotI0XX3g2csjXepP89Qax4W8//en0Pr2L5Q=="

querystring = {"outputTable": "Conversation"}
payload = '{\"query\":\"' + str(response) + '\"}'
headers = {

    'content-type': "application/json"

}
response2 = requests.request("POST", url,  headers=headers, params=querystring)
replyAns = str(response2.text)
print(replyAns)
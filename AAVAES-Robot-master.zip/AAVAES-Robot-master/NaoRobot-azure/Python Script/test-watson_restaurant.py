



import sys, os, json, base64
import requests


global chat_context

print("Comienzo")
for i in [0,1,2,3]:

    chat_context = {}
    print i

    url = 'https://nao-concierge.eu-gb.mybluemix.net/with_array'

    if i==0 :

        payload = {
            "msgdata": "restaurant"
        }

    if i==1 :

        payload = {
            "msgdata": "tacos"
        }

    if i==2:

            payload = {
                "msgdata": "second"
            }

    if i == 3:
        payload = {
            "msgdata": "today"
        }


    payload['context'] = chat_context

    r = requests.post(url, data=payload)
    response = r.json()
    if response['botresponse']:
        chat_context = response['botresponse']['messageout']['context']

        valor= len(response['botresponse']['messageout']['output']['text']) - 1
        print valor

        value =""
        for i in range(valor+1):
            print "esto vale y" + str(i)

            value = value + " " + str(response['botresponse']['messageout']['output']['text'][i])

        #value= str(response['botresponse']['messageout']['output']['text'][len(response['botresponse']['messageout']['output']['text']) - 1] )


        print(value)


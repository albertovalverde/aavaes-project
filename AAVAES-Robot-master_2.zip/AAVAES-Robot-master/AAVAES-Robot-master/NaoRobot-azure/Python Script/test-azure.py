import requests
import speech_recognition as sr
import socket
import requests
import json

response = "At what time is check-in?"
url = "https://westus.api.cognitive.microsoft.com/qnamaker/v2.0/knowledgebases/9cef4e87-4609-4461-91a7-1796e876b74b/generateAnswer"
payload = '{\"question\":\"' + "At what time is check-out?" + '\"}'
payload = '{\"question\":\"' + str(response) + '\"}'
headers = {
    'Ocp-Apim-Subscription-Key': "772b28620704441abbcc7b31fe30e90a",
    'Content-Type': "application/json"
}
response2 = requests.request("POST", url, data=payload, headers=headers)
replyAns = str(response2.text)
print(replyAns)

response = "At what time is the checkin?"
url = "https://aavaessoftware.azurewebsites.net/api/aavaesResponse?code=kRcsbFijysae6bpLd5fwHPKtaaTcZpgjPvl5PX0ArhxT6uZKs1YR9Q=="
#url = "http://localhost:7071/api/NaoResponse"
payload = '{\"query\":\"' + str(response) + '\"}'
headers = {
    'content-type': "application/json"
}
response2 = requests.request("POST", url, data=payload, headers=headers)
replyAns = str(response2.text)
print(replyAns)
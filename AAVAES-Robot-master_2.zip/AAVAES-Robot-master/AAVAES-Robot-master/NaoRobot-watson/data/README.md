# Note : 

The file in this directory - Data.csv has been downloaded from :
https://www.ibm.com/communities/analytics/watson-analytics-blog/retail-sales-marketing-profit-cost. 
Change the file name from WA_Retail-SalesMarketing_-ProfitCost.csv to Data.csv
Please visit the site for the terms and conditions for usage of the data.
